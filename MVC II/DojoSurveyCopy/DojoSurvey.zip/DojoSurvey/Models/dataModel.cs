public class survey
{
   public string Name { get; set; }
   public string Dojo{ get; set; }
   public string Comment{ get; set; }
   public string Language{ get; set; }


}