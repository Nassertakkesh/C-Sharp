namespace Dojodachi.Models
{
    public class hello
    {
        
    }
}