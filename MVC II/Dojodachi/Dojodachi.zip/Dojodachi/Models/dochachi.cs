namespace Dojodachi.Models
{
    public class dochachi
    {
             public int fullness1 { get; set; } = 20;
        public int happiness1 { get; set; } = 20;
        public int meals1 { get; set; } = 3;
        public int energy1 { get; set; } = 20;

    }
}